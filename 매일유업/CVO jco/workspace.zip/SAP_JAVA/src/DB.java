import java.sql.*;
import java.util.HashMap;

import org.apache.log4j.Logger;

public class DB {
	//static String connectionUrl = "jdbc:sqlserver://10.227.1.47:1433;database=SINDOH;";
	static String connectionUrl;
	static String dbUserId;
	static String dbPassword;
	static Logger logger = Logger.getLogger(DB.class);
	
//	public void DB_SDH_SEQ_EXEC() throws ClassNotFoundException {
//    	sdh_seq_exec();
//    }
//	
//	public void DB_SDH_CRATE_PACK_MASTER_IF(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_CRATE_PACK_MASTER_IF:"+map);
//    	sdh_crate_pack_master_if(map);
//    }
//	
//	public void DB_SDH_MATERIAL_MAINT_IF_ST(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_MATERIAL_MAINT_IF_ST:"+map);
//    	sdh_material_maint_if_st(map);
//    }
//    
//    public boolean DB_SDH_EIS_MATERIAL_CODE(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_EIS_MATERIAL_CODE:"+map);
//    	
//    	return sdh_eis_material_code(map);
//    }
//        
//    public void DB_SDH_EIS_LEVEL_CODE(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_EIS_LEVEL_CODE:"+map);
//    	sdh_eis_level_code(map);
//    }
//    
//    public void DB_SDH_SORT_MASTER_TABLE(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_SORT_MASTER_TABLE:"+map);
//    	sdh_sort_master_table(map);
//    }
//    
//    public void DB_SDH_INTAKE_AMOUNT_PACK(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_INTAKE_AMOUNT_PACK:"+map);
//    	sdh_intake_amount_pack(map);
//    }
//    
//    public void DB_SDH_SEND_SHIP_DELI_INF_SHIP(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_SEND_SHIP_DELI_INF_SHIP!:"+map);
//    	sdh_send_ship_deli_inf_ship(map);
//    }
//    
//    public void DB_SDH_SEND_SHIP_DELI_INF_DELI(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SDH_SEND_SHIP_DELI_INF_DELI!:"+map);
//    	sdh_send_ship_deli_inf_deli(map);
//    }
//    
//    public void DB_SAP_SHIP_COUNT(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_SAP_SHIP_COUNT!:"+map);
//    	sdh_sap_ship_count(map);
//    }
//    
//    public void DB_SP_DELIVERYINFO() throws ClassNotFoundException {
//    	logger.info("DB_sp_deliveryInfo!:");
//    	sdh_sp_deliveryInfo();
//    }

//    //CVO DB Operation
//    public void DB_JCO_ZCVO_ARVTM_SC(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_JCO_ZCVO_ARVTM_SC!:"+map);
//    	db_jco_zcvo_arvtm_sc(map);
//    }
//    
//    public void DB_JCO_ZCVO_CUST_SC(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_JCO_ZCVO_CUST_SC!:"+map);
//    	db_jco_zcvo_cust_sc(map);
//    }
//    
//    public void DB_JCO_ZCVO_DRIV_SC(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_JCO_ZCVO_DRIV_SC!:"+map);
//    	db_jco_zcvo_driv_sc(map);
//    }
//    
//    public void DB_JCO_ZCVO_EL_INVOICE(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_JCO_ZCVO_EL_INVOICE!:"+map);
//    	db_jco_zcvo_el_invoice(map);
//    }
//    
//    public void DB_JCO_ZCVO_PLANT_SC(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_JCO_ZCVO_PLANT_SC!:"+map);
//    	db_jco_zcvo_plant_sc(map);
//    }
//    
//    public void DB_JCO_ZCVO_SHIP_DELI_SC(HashMap<String, Object> map, HashMap<String, Object> map1) throws ClassNotFoundException {
//    	logger.info("DB_JCO_ZCVO_SHIP_DELI_SC!:"+map);
//    	db_jco_zcvo_ship(map);
//    	db_jco_zcvo_deli(map1);
//    }
//    
//    public void DB_ZCVO_BRAN_SC(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_ZCVO_BRAN_SC!:"+map);
//    	db_zcvo_bran_sc(map);
//    }
//    
//    public void DB_ZCVO_VEND_SC(HashMap<String, Object> map) throws ClassNotFoundException {
//    	logger.info("DB_ZCVO_VEND_SC!:"+map);
//    	db_zcvo_vend_sc(map);
//    }
    // CVO DB Add end
    
    public static HashMap<String, Object> db_jco_zcvo_arvtm_sc(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_arvtm_sc");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_ARVTM] 
//            	    @KUNNR		VARCHAR(10 ) 	
//                  ,  @ARVTM_MON   varchar(6)
//                  ,  @ARVTM_TUE   varchar(6)
//                  ,  @ARVTM_WED   varchar(6)
//                  ,  @ARVTM_THU   varchar(6)
//                  ,  @ARVTM_FRI   varchar(6)
//                  ,  @ARVTM_SAT   varchar(6)
//                  ,  @ARVTM_SUN   varchar(6)
//            	,   @STATS		VARCHAR(1  ) 	OUT
//                ,   @RMESG      VARCHAR(100)    OUT
//
//            	,   @RESULT_CD	VARCHAR(4) 		OUT
//            	,   @RESULT_MSG	VARCHAR(1000) 	OUT
        	CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_ARVTM(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?)}");
        	cs.setString(1, map.get("KUNNR").toString());
        	cs.setString(2, map.get("ARVTM_MON").toString());
        	cs.setString(3, map.get("ARVTM_TUE").toString());
        	cs.setString(4, map.get("ARVTM_WED").toString());
        	cs.setString(5, map.get("ARVTM_THU").toString());
        	cs.setString(6, map.get("ARVTM_FRI").toString());
        	cs.setString(7, map.get("ARVTM_SAT").toString());
        	cs.setString(8, map.get("ARVTM_SUN").toString());
        	cs.registerOutParameter(9, java.sql.Types.VARCHAR);
            cs.registerOutParameter(10, java.sql.Types.VARCHAR);
            cs.registerOutParameter(11, java.sql.Types.VARCHAR);
            cs.registerOutParameter(12, java.sql.Types.VARCHAR);
            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            //logger.info(query);
			//stmt.execute(query);

			cs.execute();
			logger.info("cs.getString(9):"+cs.getString(9));
            logger.info("cs.getString(10):"+cs.getString(10));
			logger.info("cs.getString(11):"+cs.getString(11));
            logger.info("cs.getString(12):"+cs.getString(12));
            
            HashMap<String, Object> returnMap = new HashMap<String, Object>();
            returnMap.put("STATS", cs.getString(9));
            returnMap.put("RMESG", cs.getString(10));
            returnMap.put("RESULT_CD", cs.getString(11));
            returnMap.put("RESULT_MSG", cs.getString(12));
			
            //stmt.close();   
            conn.close();
            
            return returnMap;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return null;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return null;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }

    public static boolean db_jco_zcvo_cust_sc(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_cust_sc");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_CUST] (
//            		@SEQNO		VARCHAR(10)		,	--일련번호
//            		@KUNNR		VARCHAR(10 ) 	,		--대리점코드
//            		@NAME1		VARCHAR(35 ) 	,		--대리점명
//            		@ORT01		VARCHAR(35 ) 	,		--주소(시,군,구)
//            		@PSTLZ		VARCHAR(10 ) 	,		--우편번호(신,구)
//            		@STRAS		VARCHAR(35 ) 	,		--주소,세부주소
//            		@NAME3		VARCHAR(35 ) 	,		--하역지 우편번호
//            		@NAME4		VARCHAR(35 ) 	,		--하역지 번지
//            		@TELF1		VARCHAR(16 ) 	,		--전화번호
//            		@TELF2		VARCHAR(16 ) 	,		--점주전화번호
//            		@VSBED		VARCHAR(2  ) 	,		--출하조건
//            		@VWERK		VARCHAR(4  ) 	,		--센터코드
//            		@VKGRP		VARCHAR(3  ) 	,		--영업그룹
//            		@VKBUR		VARCHAR(4  ) 	,		--사업장
//            		@J_1KFREPRE	VARCHAR(10 ) 	,		--대리점주명
//            		@ZPASS		VARCHAR(4  ) 	,		--대리점 비밀번호
//            		@CPUDT		VARCHAR(8  ) 	,		--변경일자
//            		@CPUTM		VARCHAR(6  ) 	,		--변경시간
//            		@STATS		VARCHAR(1  ) 	,		--상태표시
//            		@LOEVM		VARCHAR(1  ) 	,		--삭제표시
//            		@RMESG		VARCHAR(100) 	,		--로그메세지
//            		@RESULT_CD	VARCHAR(4) 		OUT,
//            		@RESULT_MSG	VARCHAR(1000) 	OUT
//            	)
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_CUST(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?, ?)}"); 
            cs.setString(1, map.get("SEQNO").toString());
            cs.setString(2, map.get("KUNNR").toString());
            cs.setString(3, map.get("NAME1").toString());
            cs.setString(4, map.get("ORT01").toString());
            cs.setString(5, map.get("PSTLZ").toString());
            cs.setString(6, map.get("STRAS").toString());
            cs.setString(7, map.get("NAME3").toString());
            cs.setString(8, map.get("NAME4").toString());
            cs.setString(9, map.get("TELF1").toString());
            cs.setString(10, map.get("TELF2").toString());
            cs.setString(11, map.get("VSBED").toString());
            cs.setString(12, map.get("VWERK").toString());
            cs.setString(13, map.get("VKGRP").toString());
            cs.setString(14, map.get("VKBUR").toString());
            cs.setString(15, map.get("J_1KFREPRE").toString());
            cs.setString(16, map.get("ZPASS").toString());
            cs.setString(17, map.get("CPUDT").toString());
            cs.setString(18, map.get("CPUTM").toString());
            cs.setString(19, map.get("STATS").toString());
            cs.setString(20, map.get("LOEVM").toString());
            cs.setString(21, map.get("RMESG").toString());
            cs.registerOutParameter(22, java.sql.Types.VARCHAR);
            cs.registerOutParameter(23, java.sql.Types.VARCHAR);
            
//            String query = "EXECUTE [dbo].[JCOIF_IDW_CUST] ";
//            query+="\'"+map.get("SEQNO")+"\',";
//            query+="\'"+map.get("KUNNR")+"\',";
//            query+="\'"+map.get("NAME1")+"\',";
//            query+="\'"+map.get("ORT01")+"\',";
//            query+="\'"+map.get("PSTLZ")+"\',";
//            query+="\'"+map.get("STRAS")+"\',";
//            query+="\'"+map.get("NAME3")+"\',";
//            query+="\'"+map.get("NAME4")+"\',";
//            query+="\'"+map.get("TELF1")+"\',";
//            query+="\'"+map.get("TELF2")+"\',";
//            query+="\'"+map.get("VSBED")+"\',";
//            query+="\'"+map.get("VWERK")+"\',";
//            query+="\'"+map.get("VKGRP")+"\',";
//            query+="\'"+map.get("VKBUR")+"\',";
//            query+="\'"+map.get("J_1KFREPRE")+"\',";
//            query+="\'"+map.get("ZPASS")+"\',";
//            query+="\'"+map.get("CPUDT")+"\',";
//            query+="\'"+map.get("CPUTM")+"\',";
//            query+="\'"+map.get("STATS")+"\',";
//            query+="\'"+map.get("LOEVM")+"\',";
//            query+="\'"+map.get("RMESG")+"\'";
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            //logger.info(query);
			//stmt.execute(query);
			cs.execute();
			logger.info("cs.getString(22):"+cs.getString(22));
            logger.info("cs.getString(23):"+cs.getString(23));
            //stmt.close();   
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }
    
    public static boolean db_jco_zcvo_driv_sc(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_driv_sc");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
            
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_DRIV] (
//            		@SEQNO				VARCHAR(10)		,	--일련번호
//            		@LIFNR				VARCHAR(10)		, 	--운전자코드
//            		@NAME1				VARCHAR(35)		,	--운전명
//            		@NAME2				VARCHAR(35)		,	--운전자
//            		@STRAS				VARCHAR(35)		,	--주소
//            		@ORT01				VARCHAR(35)		,	--도시
//            		@NAME4				VARCHAR(35)		,	--차량번호
//            		@TELF1				VARCHAR(16)		,	--전화번호
//            		@TELF2				VARCHAR(16)		,	--담당자전화번호
//            		@STCD1				VARCHAR(11)		,	--주민번호
//            		@LIFN2				VARCHAR(10)		,	--소속운수업체
//            		@SFRGR				VARCHAR(4) 		,	--소속공장
//            		@DLGRP				VARCHAR(4) 		,	--차량구격
//            		@CPUDT				VARCHAR(8) 		,	--변경일자
//            		@CPUTM				VARCHAR(6) 		,	--변경시간
//            		@STATS				VARCHAR(1) 		,	--상태표시
//            		@LOEVM				VARCHAR(1) 		,	--삭제표시
//            		@RMESG				VARCHAR(10)		,	--로그메시지
//            		@RESULT_CD			VARCHAR(4) 		OUT,
//            		@RESULT_MSG			VARCHAR(1000) 	OUT
            		
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_DRIV(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?)}");
            //cs.setInt(1, Integer.parseInt( map.get("SEQNO").toString().trim())); 
    		cs.setString(1, map.get("SEQNO").toString());
    		cs.setString(2, map.get("LIFNR").toString());
    		cs.setString(3, map.get("NAME1").toString());
    		cs.setString(4, map.get("NAME2").toString());
    		cs.setString(5, map.get("STRAS").toString());
    		cs.setString(6, map.get("ORT01").toString());
    		cs.setString(7, map.get("NAME4").toString());
    		cs.setString(8, map.get("TELF1").toString());
    		cs.setString(9, map.get("TELF2").toString());
    		cs.setString(10, map.get("STCD1").toString());
    		cs.setString(11, map.get("LIFN2").toString());
    		cs.setString(12, map.get("SFRGR").toString());
    		cs.setString(13, map.get("DLGRP").toString());
    		cs.setString(14, map.get("CPUDT").toString());
    		cs.setString(15, map.get("CPUTM").toString());
    		cs.setString(16, map.get("STATS").toString());
    		cs.setString(17, map.get("LOEVM").toString());
    		cs.setString(18, map.get("RMESG").toString());

            cs.registerOutParameter(19, java.sql.Types.VARCHAR);
            cs.registerOutParameter(20, java.sql.Types.VARCHAR);
            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

          //logger.info(query);
			//stmt.execute(query);
			cs.execute();
			logger.info("cs.getString(19):"+cs.getString(19));
            logger.info("cs.getString(20):"+cs.getString(20));
            //stmt.close();   
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }
    
//    public static boolean db_jco_zcvo_el_invoice(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("db_jco_zcvo_el_invoice");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
//            
//            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
//            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
//            //		+ ",CREATED_DATETIME,CREATED_BY) "
//            //		+ "VALUES "
//            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
//            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
//            //		+ ",getdate(),'SAP')";
//
//            logger.info(query);
//			stmt.execute(query);
//            
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
    
    public static boolean db_jco_zcvo_invoice_header(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_invoice_header");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_INVOICE_HEADER] (
//
//            		@SEQNO					VARCHAR(12) 		-- Sequence No.
//            		, @TKNUM					VARCHAR(10) 		-- 선적문서번호
//            		, @SHTYP					VARCHAR(4) 			-- 선적 유형
//            		, @TPLST					VARCHAR(4) 			-- 운송계획지점
//            		, @BEZEI1					VARCHAR(20) 		-- 운송계획지점 내역
//            		, @DTDIS					VARCHAR(8) 			-- 선적계획종료일
//            		, @STDIS					VARCHAR(1) 			-- 운송 계획 상태
//            		, @ROUTE					VARCHAR(6) 			-- 운송경로
//            		, @BEZEI2					VARCHAR(40) 		-- 운송경로명
//            		, @TDLNR					VARCHAR(10) 		-- 운송차량
//            		, @NAME1					VARCHAR(35) 		-- 운송차량명
//            		, @TELF1					VARCHAR(16) 		-- 첫 번째 전화번호(운송차량)
//            		, @TELF2					VARCHAR(16) 		-- 두 번째 전화번호(운송차량)
//            		, @DPABF					VARCHAR(8) 			-- 선적완료계획일
//            		, @UPDKZ					VARCHAR(1) 			-- 삭제 Flag (선적단위 갱신지시자)
//
//            		, @RESULT_CD			VARCHAR(4) OUT
//            		, @RESULT_MSG			VARCHAR(1000) OUT
//            	)
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_INVOICE_HEADER(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,  ?, ?)}");
            cs.setString(1, map.get("SEQNO").toString());
            cs.setString(2, map.get("TKNUM").toString());
            cs.setString(3, map.get("SHTYP").toString());
            cs.setString(4, map.get("TPLST").toString());
            cs.setString(5, map.get("BEZEI1").toString());
            cs.setString(6, map.get("DTDIS").toString());
            cs.setString(7, map.get("STDIS").toString());
            cs.setString(8, map.get("ROUTE").toString());
            cs.setString(9, map.get("BEZEI2").toString());
            cs.setString(10, map.get("TDLNR").toString());
            cs.setString(11, map.get("NAME1").toString());
            cs.setString(12, map.get("TELF1").toString());
            cs.setString(13, map.get("TELF2").toString());
            cs.setString(14, map.get("DPABF").toString());
            cs.setString(15, map.get("UPDKZ").toString());

            cs.registerOutParameter(16, java.sql.Types.VARCHAR);
            cs.registerOutParameter(17, java.sql.Types.VARCHAR);
            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            cs.execute();
			logger.info("cs.getString(16):"+cs.getString(16));
            logger.info("cs.getString(17):"+cs.getString(17));
            //stmt.close();
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }   
    
    public static boolean db_jco_zcvo_invoice_body(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_invoice_body");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_INVOICE_BODY] (
//
//            		@SEQNO				VARCHAR(12) 		-- Sequence No.
//            		,@TKNUM				VARCHAR(10) 		-- 선적문서번호
//            		,@TPNUM				VARCHAR(4) 			-- 선적품목
//            		,@VBELN				VARCHAR(10) 		-- 납품번호
//            		,@POSNR				VARCHAR(6) 			-- 납품품목
//            		,@MATNR				VARCHAR(18) 		-- 자재번호
//            		,@ARKTX				VARCHAR(40) 		-- LIPS-ARKTX
//            		,@WERKS				VARCHAR(4) 			-- 플랜트
//            		,@LGORT				VARCHAR(4) 			-- 저장위치
//            		,@LFIMG1				VARCHAR(13) 		-- 실제수량납품 (판매단위)
//            		,@MEINS1				VARCHAR(3) 			-- 기본 단위
//            		,@NTGEW1				VARCHAR(13) 		-- 순 중량
//            		,@BRGEW1				VARCHAR(13) 		-- 총중량
//            		,@GEWEI1				VARCHAR(3) 			-- 중량 단위
//            		,@VOLUM1			VARCHAR(13) 		-- 볼륨
//            		,@VOLEH1				VARCHAR(3) 			-- 부피 단위
//            		,@MEINH				VARCHAR(3) 			-- 환산 단위
//            		,@UMREZ				VARCHAR(5) 			-- 기본 단위로 환산하는데 사용되는 분자
//            		,@UMREN				VARCHAR(5) 			-- 기본 단위로 환산하는데 사용하는 분모
//            		,@BOX_LFIMG			VARCHAR(13) 		-- BOX 환산
//            		,@BOX_EA_LFIMG	VARCHAR(13) 		-- BOX 환산후 낱개
//            		,@LFART				VARCHAR(4) 			-- 납품유형
//            		,@VSTEL				VARCHAR(4) 			-- 출하지점
//            		,@VTEXT				VARCHAR(30) 		-- 출하지점 내역
//            		,@VKORG				VARCHAR(4) 			-- 판매조직
//            		,@WADAT				VARCHAR(8) 			-- 계획 자재 이동일(납품요청일)
//            		,@ZTIME				VARCHAR(6) 			-- 납품처 도착 예정시간
//            		,@LFDAT				VARCHAR(8) 			-- 납품일
//            		,@ROUTE				VARCHAR(6) 			-- 운송경로
//            		,@BEZEI1				VARCHAR(40) 		-- 운송경로명
//            		,@KUNNR				VARCHAR(10) 		-- 납품처
//            		,@NAME1				VARCHAR(35) 		-- 납품처명
//            		,@VKBUR				VARCHAR(4) 			-- 사업장
//            		,@BEZEI2				VARCHAR(20) 		-- 사업장명
//            		,@J_1KFREPRE			VARCHAR(10) 		-- 대리점 대표자
//            		,@TELF1					VARCHAR(16) 		-- 전화
//            		,@TELF2					VARCHAR(16) 		-- 핸드폰
//            		,@ORT01				VARCHAR(35) 		-- 주소1
//            		,@STRAS				VARCHAR(35) 		-- 주소2
//            		,@KUNAG				VARCHAR(10) 		-- 판매처
//            		,@NAME2				VARCHAR(35) 		-- 판매처명
//            		,@BTGEW2				VARCHAR(15) 		-- 총 중량
//            		,@GEWEI2				VARCHAR(3) 			-- 중량 단위
//            		,@NTGEW2				VARCHAR(15) 		-- 순 중량
//            		,@VOLUM2			VARCHAR(15) 		-- 볼륨(부피)
//            		,@VOLEH2				VARCHAR(3) 			-- 부피 단위
//            		,@ORDNO				VARCHAR(10) 		-- 주문번호
//            		,@ORDITM				VARCHAR(6) 			-- 주문행번
//            		,@ORDQTY				VARCHAR(15) 		-- 주문수량
//            		,@UPDKZ				VARCHAR(1) 			-- 삭제 Flag (납품단위 갱신지시자)
//
//            		,@RESULT_CD			VARCHAR(4) OUT
//            		,@RESULT_MSG		VARCHAR(1000) OUT
//            	)
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_INVOICE_BODY(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?)}");
            cs.setString(1, map.get("SEQNO").toString());
            cs.setString(2, map.get("TKNUM").toString());
            cs.setString(3, map.get("TPNUM").toString());
            cs.setString(4, map.get("VBELN").toString());
            cs.setString(5, map.get("POSNR").toString());
            cs.setString(6, map.get("MATNR").toString());
            cs.setString(7, map.get("ARKTX").toString());
            cs.setString(8, map.get("WERKS").toString());
            cs.setString(9, map.get("LGORT").toString());
            cs.setString(10, map.get("LFIMG1").toString());
            cs.setString(11, map.get("MEINS1").toString());
            cs.setString(12, map.get("NTGEW1").toString());
            cs.setString(13, map.get("BRGEW1").toString());
            cs.setString(14, map.get("GEWEI1").toString());
            cs.setString(15, map.get("VOLUM1").toString());
            cs.setString(16, map.get("VOLEH1").toString());
            cs.setString(17, map.get("MEINH").toString());
            cs.setString(18, map.get("UMREZ").toString());
            cs.setString(19, map.get("UMREN").toString());
            cs.setString(20, map.get("BOX_LFIMG").toString());
            cs.setString(21, map.get("BOX_EA_LFIMG").toString());
            cs.setString(22, map.get("LFART").toString());
            cs.setString(23, map.get("VSTEL").toString());
            cs.setString(24, map.get("VTEXT").toString());
            cs.setString(25, map.get("VKORG").toString());
            cs.setString(26, map.get("WADAT").toString());
            cs.setString(27, map.get("ZTIME").toString());
            cs.setString(28, map.get("LFDAT").toString());
            cs.setString(29, map.get("ROUTE").toString());
            cs.setString(30, map.get("BEZEI1").toString());
            cs.setString(31, map.get("KUNNR").toString());
            cs.setString(32, map.get("NAME1").toString());
            cs.setString(33, map.get("VKBUR").toString());
            cs.setString(34, map.get("BEZEI2").toString());
            cs.setString(35, map.get("J_1KFREPRE").toString());
            cs.setString(36, map.get("TELF1").toString());
            cs.setString(37, map.get("TELF2").toString());
            cs.setString(38, map.get("ORT01").toString());
            cs.setString(39, map.get("STRAS").toString());
            cs.setString(40, map.get("KUNAG").toString());
            cs.setString(41, map.get("NAME2").toString());
            cs.setString(42, map.get("BTGEW2").toString());
            cs.setString(43, map.get("GEWEI2").toString());
            cs.setString(44, map.get("NTGEW2").toString());
            cs.setString(45, map.get("VOLUM2").toString());
            cs.setString(46, map.get("VOLEH2").toString());
            cs.setString(47, map.get("ORDNO").toString());
            cs.setString(48, map.get("ORDITM").toString());
            cs.setString(49, map.get("ORDQTY").toString());
            cs.setString(50, map.get("UPDKZ").toString());

            cs.registerOutParameter(51, java.sql.Types.VARCHAR);
            cs.registerOutParameter(52, java.sql.Types.VARCHAR);
            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            cs.execute();
			logger.info("cs.getString(51):"+cs.getString(51));
            logger.info("cs.getString(52):"+cs.getString(52));
            //stmt.close();
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }   
    
    public static boolean db_jco_zcvo_plant_sc(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_plant_sc");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_PLANT] (
//            		@SEQNO				VARCHAR(10),	--일련번호
//            		@WERKS 				VARCHAR(4),
//            		@NAME1 				VARCHAR(30),
//            		@CPUDT				VARCHAR(8),
//            		@CPUTM 				VARCHAR(6),
//            		@STATS				VARCHAR(1),
//            		@RESULT_CD			VARCHAR(4) OUT,
//            		@RESULT_MSG			VARCHAR(1000) OUT
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_PLANT(?, ?, ?, ?, ?,   ?, ?, ?)}");
            //cs.setInt(1, Integer.parseInt( map.get("SEQNO").toString().trim())); 
            cs.setString(1, map.get("SEQNO").toString());
            cs.setString(2, map.get("WERKS").toString());
            cs.setString(3, map.get("NAME1").toString());
            cs.setString(4, map.get("CPUDT").toString());
            cs.setString(5, map.get("CPUTM").toString());
            cs.setString(6, map.get("STATS").toString());
            cs.registerOutParameter(7, java.sql.Types.VARCHAR);
            cs.registerOutParameter(8, java.sql.Types.VARCHAR);
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            //logger.info(query);
			//stmt.execute(query);
			cs.execute();
			logger.info("cs.getString(7):"+cs.getString(7));
            logger.info("cs.getString(8):"+cs.getString(8));
            //stmt.close();   
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }
    
    
//    public static boolean db_jco_zcvo_ship_deli_sc(HashMap<String, Object> mapShip, HashMap<String, Object> mapDeli) throws ClassNotFoundException {
//        try {
//        	logger.info("db_jco_zcvo_ship_deli_sc");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
//            
//            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
//            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
//            //		+ ",CREATED_DATETIME,CREATED_BY) "
//            //		+ "VALUES "
//            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
//            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
//            //		+ ",getdate(),'SAP')";
//
//            logger.info(query);
//			stmt.execute(query);
//            
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
    
    public static boolean db_jco_zcvo_ship(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_ship");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_SHIP] (
//            		@SEQNO 				VARCHAR(10),	--일련번호
//            		@TKNUM 				VARCHAR(10),	--선적번호
//            		@VBELN				VARCHAR(10),	--납품번호
//            		@WADAT				VARCHAR(8),		--납품요청일
//            		@TDLNR 				VARCHAR(10),	--운수업체코드(기사번호)
//            		@TPLST				VARCHAR(4),		--센터코드
//            		@UPDKZ				VARCHAR(1),		--삭제Flag
//            		@SEQNO2				VARCHAR(11),	--로그SEQ
//            		@RESULT_CD			VARCHAR(4) OUT,
//            		@RESULT_MSG			VARCHAR(1000) OUT
//            	)
//            	AS
//            	BEGIN
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_SHIP(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?)}");
            cs.setString(1, map.get("SEQNO").toString());
            cs.setString(2, map.get("TKNUM").toString());
            cs.setString(3, map.get("VBELN").toString());
            cs.setString(4, map.get("WADAT").toString());
            cs.setString(5, map.get("TDLNR").toString());
            cs.setString(6, map.get("TPLST").toString());
            cs.setString(7, map.get("UPDKZ").toString());
            cs.setString(8, map.get("SEQNO2").toString());
            cs.registerOutParameter(9, java.sql.Types.VARCHAR);
            cs.registerOutParameter(10, java.sql.Types.VARCHAR);
            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            cs.execute();
			logger.info("cs.getString(9):"+cs.getString(9));
            logger.info("cs.getString(10):"+cs.getString(10));
            //stmt.close();   
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }
    
    public static boolean db_jco_zcvo_deli(HashMap<String, Object> map) throws ClassNotFoundException {
        try {
        	logger.info("db_jco_zcvo_deli");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
            //Statement stmt = conn.createStatement();
            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
            
//            ALTER PROCEDURE [dbo].[JCOIF_IDW_DELI] (
//            		@SEQNO				VARCHAR(10),	--일련번호
//            		@VBELN 				VARCHAR(10),	--납품번호
//            		@WERKS 				VARCHAR(4),		--센터코드
//            		@MATNR 				VARCHAR(18),	--자재코드
//            		@LFIMG				VARCHAR(13),	--수량
//            		@KUNNR 				VARCHAR(10),	--대리점코드
//            		@WADAT				VARCHAR(8),		--납품요청일
//            		@ZTIME				VARCHAR(6),		--도착예정시간
//            		@UPDKZ				VARCHAR(1),		--삭제Flag
//            		@SEQNO2				VARCHAR(11),	--로그SEQ
//            		@RESULT_CD			VARCHAR(4) OUT,
//            		@RESULT_MSG			VARCHAR(1000) OUT
//            	)
            
            CallableStatement cs = conn.prepareCall("{call JCOIF_IDW_DELI(?, ?, ?, ?, ?,   ?, ?, ?, ?, ?,   ?, ?)}");
            cs.setString(1, map.get("SEQNO").toString());
            cs.setString(2, map.get("VBELN").toString());
            cs.setString(3, map.get("WERKS").toString());
            cs.setString(4, map.get("MATNR").toString());
            cs.setString(5, map.get("LFIMG").toString());
            cs.setString(6, map.get("KUNNR").toString());
            cs.setString(7, map.get("WADAT").toString());
            cs.setString(8, map.get("ZTIME").toString());
            cs.setString(9, map.get("UPDKZ").toString());
            cs.setString(10, map.get("SEQNO2").toString());
            cs.registerOutParameter(11, java.sql.Types.VARCHAR);
            cs.registerOutParameter(12, java.sql.Types.VARCHAR);
//            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
            
            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
            //		+ ",CREATED_DATETIME,CREATED_BY) "
            //		+ "VALUES "
            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
            //		+ ",getdate(),'SAP')";

            cs.execute();
			logger.info("cs.getString(11):"+cs.getString(11));
            logger.info("cs.getString(12):"+cs.getString(12));
            //stmt.close();   
            conn.close();
            return true;
        } catch (SQLException sqle) {
            logger.info("SQLException : " + sqle.getMessage());
            //conn.close();
            return false;
        } catch (Exception e) {
            logger.info("Exception : " + e.getMessage());
            //conn.close();
            return false;
        } finally{
        	logger.info("finally : ");
        	//conn.close();
        }
    }
    
    public static boolean db_zcvo_bran_sc(HashMap<String, Object> map) throws ClassNotFoundException {
    	
        return true;
        
//    	try {
//        	logger.info("db_zcvo_bran_sc");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
//            
//            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
//            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
//            //		+ ",CREATED_DATETIME,CREATED_BY) "
//            //		+ "VALUES "
//            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
//            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
//            //		+ ",getdate(),'SAP')";
//
//            logger.info(query);
//			stmt.execute(query);
//            
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
    }
    
    public static boolean db_zcvo_vend_sc(HashMap<String, Object> map) throws ClassNotFoundException {
        
    	return true;
    	
//    	try {
//        	logger.info("db_zcvo_vend_sc");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
//            
//            //String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
//            //		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
//            //		+ ",CREATED_DATETIME,CREATED_BY) "
//            //		+ "VALUES "
//            //		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
//            //		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
//            //		+ ",getdate(),'SAP')";
//
//            logger.info(query);
//			stmt.execute(query);
//            
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
    }
    
//    public static void sdh_sp_deliveryInfo() throws ClassNotFoundException {
//        try {
//        	logger.info("sdh_sp_deliveryInfo");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            
//            String query = "EXECUTE [dbo].[sp_deliveryInfo] ";
//            logger.info(query);
//			stmt.execute(query);
//            
//            stmt.close();   
//            conn.close();
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//        }
//    }
//    
//    public static void sdh_sap_ship_count(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("sdh_sap_ship_count");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            
//            String query = "EXECUTE [dbo].[sp_maeil_sap_shipment_count] ";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+=map.get("TKNUM_CNT")+",";
//            query+=map.get("VBELN_CNT")+",";
//            query+=map.get("TKNUM_CNT_R")+",";
//            query+=""+map.get("VBELN_CNT_R");
//            
//            /*String query = "INSERT INTO dbo.MAEIL_SAP_SHIPMENT_COUNT "
//            		+ "(SAP_DATE,WERKS, TKNUM_CNT,VBELN_CNT,TKNUM_CNT_R,VBELN_CNT_R"
//            		+ ",CREATED_DATETIME,CREATED_BY) "
//            		+ "VALUES "
//            		+ "(getdate(),\'"+map.get("WERKS")+"\',"+map.get("TKNUM_CNT")+","+map.get("VBELN_CNT")+","
//            		+map.get("TKNUM_CNT_R")+","+map.get("VBELN_CNT_R")+""
//            		+ ",getdate(),'SAP')";
//
//*/            logger.info(query);
//			stmt.execute(query);
//            
//            stmt.close();   
//            conn.close();
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//        }
//    }
//    
//    public boolean sdh_crate_pack_master_if(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("sdh_crate_pack_master_if");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            
//            String query = "EXECUTE [dbo].[sp_maeil_3001] ";
//            query+="\'"+map.get("VSTEL")+"\',";
//            query+="\'"+map.get("MATNR")+"\',";
//            query+="\'"+map.get("LFIMG")+"\',";
//            query+="\'"+map.get("MEINS")+"\',";
//            query+="\'"+map.get("VHILM")+"\',";
//            query+="\'S\',";
//            query+="\'\' ";
//		  
//
//            logger.info(query);
//            stmt.execute(query);
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//        	//로그에 에러 메시지와 쿼리를 남기기
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//    
//    public static String sdh_seq_exec() throws ClassNotFoundException {
//    	String SEQ_EXEC =null;
//    	try {
//        	logger.info("sdh_seq_exec");
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            
//            String query = "SELECT NEXT VALUE FOR SEQ_EXEC AS SEQ_EXEC ";
//            logger.info(query);
//            
//            ResultSet rs = null;
//            rs = stmt.executeQuery(query);
//            while( rs.next() ) {
//            	SEQ_EXEC = rs.getString("SEQ_EXEC");
//                logger.info("SEQ_EXEC : " + SEQ_EXEC);
//             }
//            
//            rs.close();
//            stmt.close();   
//            conn.close();
//            return SEQ_EXEC;
//        } catch (SQLException sqle) {
//        	//로그에 에러 메시지와 쿼리를 남기기
//            logger.info("SQLException : " + sqle);
//            return SEQ_EXEC;
//        }
//    }
//    
//    
//    
//    public static boolean sdh_material_maint_if_st(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("DBinsert sdh_material_if_st!!:"+map);
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3002] ";
//	            query+="\'"+map.get("MATNR")+"\',";
//	            query+="\'"+map.get("WERKS")+"\',";
//	            query+="\'"+map.get("MEINS")+"\',";
//	            query+="\'"+map.get("ZBOX")+"\',";
//	        	query+="\'"+map.get("ZPAL")+"\',";
//	            query+="\'S\',";
//	            query+="\'"+"\'";
//
//            logger.info(query);
//            stmt.execute(query);
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//    
//    
//    
//    public boolean sdh_eis_material_code(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("DBinsert sdh_eis_material_code!!:"+map);
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3003] ";
//    		query+="\'"+map.get("ZLEV1")+"\',";
//    		query+="\'"+map.get("ZLEV2")+"\',";
//			query+="\'"+map.get("ZLEV3")+"\',";
//			query+="\'"+map.get("MATNR")+"\',";
//			query+="\'"+map.get("ZUSER")+"\',";
//			query+="\'"+map.get("DATUM")+"\',";
//			query+="\'"+map.get("UZEIT")+"\',";
//			query+="\'"+map.get("LVORM")+"\',";
//			query+="\'S',";
//			query+="\'\'";
//
//            logger.info(query);
//            stmt.execute(query);
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//    
//    public static boolean sdh_eis_level_code(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("DBinsert sdh_eis_level_code!!:"+map);
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3004] ";
//			query+="\'"+map.get("ZLEVEL")+"\',";
//			query+="\'"+map.get("ZCODE")+"\',";
//			query+="\'"+map.get("ZCODE_NAME")+"\',";
//			query+="\'"+map.get("ZUSER")+"\',";
//			query+="\'"+map.get("DATUM")+"\',";
//			query+="\'"+map.get("UZEIT")+"\',";
//			query+="\'"+map.get("LVORM")+"\',";
//			query+="\'S\',";
//			query+="\'\'";
//            logger.info(query);
//            stmt.execute(query);
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//    
//    public static boolean sdh_sort_master_table(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("DBinsert sdh_sort_master_table!!:"+map);
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3005] ";
//			query+="\'"+map.get("WERKS")+"\',";
//			query+="\'"+map.get("LGORT")+"\',";
//			query+="\'"+map.get("MATNR")+"\',";
//			query+="\'"+map.get("MAKTX").toString().replace("'", "''")+"\',";
//			if(Integer.parseInt(map.get("ZSORT").toString())==0){
//				query+="\'9999\',";
//			}else{
//				query+="\'"+Integer.parseInt(map.get("ZSORT").toString())+"\',";	
//			}
//			query+="\'"+map.get("LVORM")+"\',";
//			query+="\'S',";
//			query+="\'\'";
//        			
//            logger.info(query);
//            stmt.execute(query);
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//    
//    public static boolean sdh_intake_amount_pack(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("DBinsert sdh_intake_amount_pack!!:"+map);
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//	
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3006] ";
//                            
//            query+="\'"+map.get("MATNR")+"\',";
//            query+="\'"+map.get("MEINH")+"\',";
//            query+="\'"+map.get("UMREZ")+"\',";
//            query+="\'"+map.get("UMREN")+"\',";
//            query+="\'"+map.get("EAN11")+"\',";
//            query+="\'"+map.get("LVORM")+"\',";
//            query+="\'S\',";
//			query+="\'\'";
//			
//            logger.info(query);
//            stmt.execute(query);
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//   
//    public static boolean sdh_send_ship_deli_inf_ship(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("sdh_send_ship_deli_inf_ship!!");
//        	logger.info("mmmap!!:"+map);
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3010] ";
//            query+="\'"+map.get("SEQNO")+"\',";
//            query+="\'"+map.get("TKNUM")+"\',";
//            query+="\'"+map.get("SHTYP")+"\',";
//            query+="\'"+map.get("TPLST")+"\',";
//            query+="\'"+map.get("BEZEI1")+"\',";
//            query+="\'"+map.get("DTDIS")+"\',";
//            query+="\'"+map.get("STDIS")+"\',";
//            query+="\'"+map.get("ROUTE")+"\',";
//            query+="\'"+map.get("BEZEI2")+"\',";
//            query+="\'"+map.get("TDLNR")+"\',";
//            query+="\'"+map.get("NAME1")+"\',";
//            query+="\'"+map.get("TELF1")+"\',";
//            query+="\'"+map.get("TELF2")+"\',";
//            query+="\'"+map.get("DPABF")+"\',";
//            query+="\'"+map.get("UPDKZ")+"\',";
//            //query+="\'"+map.get("SNDOK")+"\',";
//            //query+="\'"+map.get("MESSAGE")+"\',";
//            query+="\'\',";
//            query+="\'\',";
//            query+=map.get("SEQ_EXEC");
//            
//            logger.info(query);
//            //ResultSet rs = stmt.executeQuery(query);
//            stmt.execute(query);
//            
//            /*while( rs.next() ) {
//                   String field1 = rs.getString("TITLE");
//                   String field2 = rs.getString("UNIT");
//                   System.out.print(field1 + "\t");
//                   logger.info(field2);
//                  }*/
//            //rs.close();
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
//    
//    public static boolean sdh_send_ship_deli_inf_deli(HashMap<String, Object> map) throws ClassNotFoundException {
//        try {
//        	logger.info("sdh_send_ship_deli_inf_deli");
//        	logger.info("connectionUrl:"+connectionUrl);
//        	
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            
//            Connection conn = DriverManager.getConnection(connectionUrl, dbUserId, dbPassword);
//            Statement stmt = conn.createStatement();
//            //logger.info("MS-SQL 서버 접속에 성공하였습니다.!!");
//            String query = "EXECUTE [dbo].[sp_maeil_3011] ";
//            query+="\'"+map.get("SEQNO")+"\',";
//            query+="\'"+map.get("TKNUM")+"\',";
//            query+="\'"+map.get("TPNUM")+"\',";
//            query+="\'"+map.get("VBELN")+"\',";
//            query+="\'"+map.get("POSNR")+"\',";
//            query+="\'"+map.get("MATNR")+"\',";
//            query+="\'"+map.get("ARKTX")+"\',";
//            query+="\'"+map.get("WERKS")+"\',";
//            query+="\'"+map.get("LGORT")+"\',";
//            query+="\'"+map.get("LFIMG1")+"\',";
//            query+="\'"+map.get("MEINS1")+"\',";
//            query+="\'"+map.get("NTGEW1")+"\',";
//            query+="\'"+map.get("BRGEW1")+"\',";
//            query+="\'"+map.get("GEWEI1")+"\',";
//            query+="\'"+map.get("VOLUM1")+"\',";
//            query+="\'"+map.get("VOLEH1")+"\',";
//            query+="\'"+map.get("MEINH")+"\',";
//            query+="\'"+map.get("UMREZ")+"\',";
//            query+="\'"+map.get("UMREN")+"\',";
//            query+="\'"+map.get("BOX_LFIMG")+"\',";
//            query+="\'"+map.get("BOX_EA_LFIMG")+"\',";
//            query+="\'"+map.get("LFART")+"\',";
//            query+="\'"+map.get("VSTEL")+"\',";
//            query+="\'"+map.get("VTEXT")+"\',";
//            query+="\'"+map.get("VKORG")+"\',";
//            query+="\'"+map.get("WADAT")+"\',";
//            query+="\'"+map.get("ZTIME")+"\',";
//            query+="\'"+map.get("LFDAT")+"\',";
//            query+="\'"+map.get("ROUTE")+"\',";
//            query+="\'"+map.get("BEZEI1")+"\',";
//            query+="\'"+map.get("KUNNR")+"\',";
//            query+="\'"+map.get("NAME1")+"\',";
//            query+="\'"+map.get("VKBUR")+"\',";
//            query+="\'"+map.get("BEZEI2")+"\',";
//            query+="\'"+map.get("J_1KFREPRE")+"\',";
//            query+="\'"+map.get("TELF1")+"\',";
//            query+="\'"+map.get("TELF2")+"\',";
//            query+="\'"+map.get("ORT01")+"\',";
//            query+="\'"+map.get("STRAS")+"\',";
//            query+="\'"+map.get("KUNAG")+"\',";
//            query+="\'"+map.get("NAME2")+"\',";
//            query+="\'"+map.get("BTGEW2")+"\',";
//            query+="\'"+map.get("GEWEI2")+"\',";
//            query+="\'"+map.get("NTGEW2")+"\',";
//            query+="\'"+map.get("VOLUM2")+"\',";
//            query+="\'"+map.get("VOLEH2")+"\',";
//            query+="\'"+map.get("UPDKZ")+"\',";
//            //query+="\'"+map.get("SNDOK")+"\',";
//            //query+="\'"+map.get("MESSAGE")+"\',";
//            query+="\'\',";
//            query+="\'\',";
//            query+=map.get("SEQ_EXEC");
//            
//            logger.info(query);
//            stmt.execute(query);
//            
//            /*while( rs.next() ) {
//                   String field1 = rs.getString("TITLE");
//                   String field2 = rs.getString("UNIT");
//                   System.out.print(field1 + "\t");
//                   logger.info(field2);
//                  }*/
//            //rs.close();
//            stmt.close();   
//            conn.close();
//            return true;
//        } catch (SQLException sqle) {
//            logger.info("SQLException : " + sqle);
//            return false;
//        }
//    }
}